'use strict'

// eslint-disable-next-line no-unused-vars
function flipCard(event){
	event.target.closest('.flip-card').classList.toggle('flip');
}