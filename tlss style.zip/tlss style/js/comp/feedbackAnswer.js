$('.feedback-btn').on('click', function() {
    $(this).next('.feedback-div').show();
    if (!$(this).hasClass('disabled')) {
        $(this).addClass('disabled')
    }
    $(this).next('.feedback-div').show();
})

function enableFeedbackbutton(target) {
    var charLength = target.value.length;
    if (charLength > 1) {
        $(target).next('.feedback-btn').removeClass('disabled')
    }
}