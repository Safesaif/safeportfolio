'use strict'


$(document).ready(function(){

	$(function () {
		$('[data-toggle="tooltip"]').tooltip()
	})

	$('.card').each(function(){
		var collapsableDiv = $(this).find('.collapse');
		if (collapsableDiv.hasClass('show')) {
			$(this).find('.rotate').addClass('down')
		}
	})

	$('.card-header').click(function(){
		setTimeout(function(){
			$('.card').each(function(index, item) {
				var collapsableDiv = $(item).find('.collapse');
				if (collapsableDiv.hasClass('show')) {
					$(item).find('.rotate').addClass('down')
				} else {
					$(item).find('.rotate').removeClass('down')
					
				}
				$(item).find('.rotate').toggleClass('down');
			})
		},375)
	})


    $('.feedback-btn').on('click', function() {
        $(this).next('.feedback-div').show();
        if (!$(this).hasClass('disabled')) {
            $(this).addClass('disabled')
        }
        $(this).next('.feedback-div').show();
    })

//	$('#pullQuote-1').load(loadPullQuote('#pullQuote-1', 1.30));
});

//Set the height of "pull-quote" components automatically 
function loadPullQuote(element, heightRatio) {
	setTimeout(function() {

		var thisId = $(element).attr('id');
		var pullCardPadding = parseInt($(element).children('.pull-quote-card').css('padding-top')) + parseInt($(element).children('.pull-quote-card').css('padding-bottom'));
		var thisMinHeight = ($(element).children('.pull-quote-card').height() + pullCardPadding) * heightRatio;

		$(element).css('min-height', thisMinHeight);
		$(element).find('.pull-mark').css('min-height', thisMinHeight)
		$('<style>#' + thisId + ' .pull-mark:before{border-bottom: ' + thisMinHeight + 'px solid transparent;}</style>').appendTo('head');
		
	},800)
}

function enableFeedbackbutton(target) {
    var charLength = target.value.length;
    if (charLength > 1) {
        $(target).next('.feedback-btn').removeClass('disabled')
    }
}

function playGif(element) {
	$(element).find('.anim-img').removeClass('hidden');
	$(element).find('.placeholder-img').addClass('hidden');
}

function openTextbox(element, targetParent, position) {

	switch(position) {
	
	case 'above':
		$(targetParent).animate({marginTop: '260px'}, 200);
		$(element).show();
		break;

	case 'inline':
		$(element).css('display', 'inline-block');
	}	
	
}

//Check how many checkboxes are being checked in each checkbox form element and release "Submit" 
function enableSubmitOnCheck(targetForm) {
	var _checksCounting = 0;
	var _checkForm = document.getElementById(targetForm);
	var _checkInputs = _checkForm.getElementsByTagName('input');
	for (var l=0; l<_checkInputs.length; l++){
		if (_checkInputs[l].checked) {
			_checksCounting++
			if (_checksCounting === 1) {
				// _checkInputs[l].parentElement.parentElement.parentElement.parentElement.parentElement.parentElement.querySelector('.survey-submit-btn').classList.remove('disabled');
				_checkForm.parentElement.querySelector('.survey-submit-btn').classList.remove('disabled');
			}
			// console.log('foo')
		}
	}
}