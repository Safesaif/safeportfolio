/* eslint-disable strict */
//Documentation: https://www.chartjs.org/docs/latest/charts/bar.html

var mem6260W1Key = 'ZOApEbsnL5cTFw5XadY13C3WpNHLjv2zUqYwPuCn';

// function renderChart(surveyID, surveyType, lrsID, lrsKey) {
function renderChart(surveyID, lrsID, lrsKey) {

	//Hiding submit button in the survey
	// document.getElementById(surveyID).parentElement.querySelector('.survey-submit-btn').style.display = 'none';

	var survey = surveyID;
	var authStr = lrsID + ':' + lrsKey;
	var renderingForm = document.getElementById(surveyID);
	var radioSelected;

	// console.log(authStr);
	// console.log(typeof authStr);

	//Store data to the LRS
	(function send_statement(){  

		var conf = null;
		var statement;

		conf = {  
			'endpoint' : 'https://cloud.scorm.com/lrs/' + lrsID + '/',  
			'auth' : 'Basic ' + toBase64(authStr)  
		};
			
		ADL.XAPIWrapper.changeConfig(conf)

		// if (surveyType === 'check') {
		var targetFormCheck = document.getElementById(surveyID);
		var _targetInputs = targetFormCheck.getElementsByTagName('input');

		for (var i=0; i<_targetInputs.length; i++){
			if (_targetInputs[i].checked) {

				//define the xapi statement being sent  
				statement = {  
					'actor': {  
						'mbox': 'mailto:nobody@nobody.com',  
						'name': 'Learner',  
						'objectType': 'Agent'  
					},  
					'verb': {  
						'id': 'http://example.com/xapi/answered',  
						'display': {'en-US': 'answered'}  
					},  
					'object': {  
						'id': 'http://example.com/?answerValue',  
						// "id": answerValue, 
						'definition': {  
							'name': {'en-US': _targetInputs[i].value},  
							'description': {'en-US': 'Survey value'}  
						},  
						'objectType': 'Activity'  
					}  
				}; //end statement definition  

				console.log(statement);

				// Dispatch the statement to the LRS  
				var result = ADL.XAPIWrapper.sendStatement(statement);

			}
		}
		// }
			
		_targetInputs = null;
			
	})();

	//Retreive data from the LRS
	(function get_statements(surveyID) {

		var conf = null;

		conf = {  
			'endpoint' : 'https://cloud.scorm.com/lrs/' + lrsID + '/',  
			'auth' : 'Basic ' + toBase64(authStr)  
		};
			
		ADL.XAPIWrapper.changeConfig(conf)        
		var ret = ADL.XAPIWrapper.getStatements();

		var statementsArr = ret.statements;

		var surveyInputs = document.getElementById(survey).elements;
		var chartDataArr = [];

		for (var c=0; c<surveyInputs.length; c++) {
			var chartDataArrItem = new Array(surveyInputs[c].defaultValue, 0)
			chartDataArr.push(chartDataArrItem)
		}

		for (var i = 0; i<statementsArr.length; i++) {

			for (var j=0; j<chartDataArr.length; j++) {
				if (statementsArr[i].object.definition.name['en-US'] === chartDataArr[j][0]) {
					chartDataArr[j][1]++
				}
			}
		}
		
		createChart(chartDataArr); 

	})();

	if (renderingForm.classList.contains('js-trueFalse')) {
		// enableFeedbackTrueFalse(_checkForm)
		var _targetInputs = renderingForm.getElementsByTagName('input');

		for (var i=0; i<_targetInputs.length; i++){
			if (_targetInputs[i].checked) {
				radioSelected = _targetInputs[i].value
			}
		}

		enableFeedbackTrueFalse(surveyID, radioSelected);
	}

	function createChart(sourceData) {
		var ctx = document.getElementById('Chart').getContext('2d');
		var labelsArr = [];
		var resultsArr = [];

		for (var a=0; a<sourceData.length; a++) {
			labelsArr.push(sourceData[a][0]);
			resultsArr.push(sourceData[a][1]);
		}

		Chart.defaults.font.size = 16;
		// Chart.defaults.legend.display = false;

		new Chart(ctx, {
			type: 'bar',
			data: {
				labels: labelsArr,
				datasets: [{
					label: '# of Votes',
					data: resultsArr,
					barPercentage: 0.5,
					barThickness: 15,
					maxBarThickness: 20,
					minBarLength: 6,
					backgroundColor: [
						'rgba(12, 76, 132, 0.65)',
						'rgba(252, 163, 4, 0.65)',
						'rgba(175, 0, 46, 0.65)',
						'rgba(4, 196, 220, 0.65)',
						'rgba(252, 100, 4, 0.65)',
						'rgba(rgba(3, 166, 166, 0.65)'
					],
					borderColor: [
						'rgba(12, 76, 132, 0.65)',
						'rgba(252, 163, 4, 0.65)',
						'rgba(175, 0, 46, 0.65)',
						'rgba(4, 196, 220, 0.65)',
						'rgba(252, 100, 4, 0.65)',
						'rgba(rgba(3, 166, 166, 0.65)'
					],
					borderWidth: 1
				}]
			},
			options: {
				responsive: true,
				maintainAspectRatio: false,
				tooltips: {
					callbacks: {
						label: function(tooltipItem) {
							return tooltipItem.yLabel;
						}
					}
				},
				scales: {
					x: {
						beginAtZero: true
					},
					xAxes: [{
						gridLines: {
							lineWidth: 0
						}
					}],
					yAxes: [{
						gridLines: {
							lineWidth: 0
						}   
					}]
				},
				indexAxis: 'y',
				plugins: {
					legend: {
						display: false,
						labels: {
							// This more specific font property overrides the global property
							font: {
								size: 16,
								family: 'Roboto'
							}
						}
					}
				}
			}
		});
	}

	//Enable relevant feedback for True/False surveys
	function enableFeedbackTrueFalse(targetForm, SelectedInputValue) {

		switch(targetForm) {

		case 'radioForm1':
			if (SelectedInputValue === 'False') {
				document.getElementById(targetForm).parentElement.querySelector('.survey-results-area').querySelector('.banner.success').classList.remove('hidden');
			} else {
				document.getElementById(targetForm).parentElement.querySelector('.survey-results-area').querySelector('.banner.error').classList.remove('hidden');
			}
			break;
			
		}

	}

	//Expand survey area
	document.getElementById(surveyID).parentElement.classList.add('expanded');

	//Showing survey results with charts
	document.getElementById(surveyID).parentElement.querySelector('.survey-results-area').style.display = 'block';
}