



/*
var win = window.open("UN.html", "Title", "toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=yes,resizable=yes,width=780,height=200,top="+(screen.height-400)+",left="+(screen.width-840));
win.document.body.innerHTML = "HTML"; */


$(function(){
  $('[data-toggle="popover"]').popover();    

  
  /* MEM 6285 - Accordion : change border-color if card is .collapse.show */ 
  $('.accordion.type3>.card').on('show.bs.collapse', function () {
      $(this).addClass("bra-brand-primary-base")
  });
  $('.accordion.type3>.card').on('hide.bs.collapse', function () {
    $(this).removeClass("bra-brand-primary-base")
  });
  

  /* Image Overlay onClick */
  $(".showOverlay").click(
    function(){ 
      $(this).closest('.img-with-overlay-onclick ').find('.overlay').css("opacity","0.75");
      $(this).hide();
      $(".hideOverlay").show()
    }
  )

  $(".hideOverlay").click(
    function(){ 
      $(this).closest('.img-with-overlay-onclick ').find('.overlay').css("opacity", "0");
      $(this).hide();
      $(".showOverlay").show();
    }
  )
})


// .tab4bn & .tab2xbn patch (.active on/off)
$(".tabsplit .nav-link").click(function(){

  $(this).closest(".tabsplit").find(".nav-link").removeClass("active");
  $(this).addClass("active");

  anchor = $(this).attr("href")

  $(this).closest(".tabsplit").find(".tab-pane").removeClass("show").hide()
  $(anchor).addClass("show").show()
})

$(".tab2xbn .nav-link").click(function(){

  $(this).closest(".tab2xbn").find(".nav-link").removeClass("active");
  $(this).addClass("active");

  anchor = $(this).attr("href")

  $(this).closest(".tab2xbn").find(".tab-pane").removeClass("visible").removeClass("show").hide()
  $(anchor).addClass("show").addClass("visible").show()
})






/*
GLOSSAIRE */

var glossary = {
  'profitability':'The ability of a business to make profit after deducting all relevant expenses associated with its operation',
  
  'processes and capabilities':'The required investment in business processes to allow its operation to achieve the desired outcome with the least amount of waste and the maximum value ',

  'strategy for value creation':'Alignment of the business operation to its business strategy to achieve the desired and committed to profit targets ',
  'cost':'The expense associated with the creation of a product or service',
  
  'quality/quantity tools':'The value of a product or service as defined by the customer (not the organization)',

  'timeless':'The ability to create Goods and Services in a timely manner based on what the customer wants rather than capacity availability. This requirement should not cost the customer premiums but rather an organization should have flexible capacity to produce the products or services when the customer requires it – within reason of course',

  'capacity':'The organization’s availability of resources (space, equipment, and manpower) to generate more output, if needed',

  'facilities':'Space and location availability to generate and provide the best value to the customer',

  'workforce':'Availability and training of required manpower to produce the required demand',
  'lean systems' : 'A business process that is adopted by the producer of goods or services with the minimal amount of waste and maximum efficiency',

  'resource planning':'Efficient planning of available resources to ensure the highest efficiency in the usage of an organization’s resources',

  'supply chain mangement':'An efficient, flexible, and rapid availability of supply when needed to ensure less downtime and waiting, which leads to the unavailability of products and services',

  'inventory':'Carrying the right amount of inventory to ensure the least amount of disruption to the production of goods and services without increasing the liability of inventory losses or storage costs',

  'foundations for success':'Businesses can only survive if they can maintain targeted profits, continue to invest in their processes and capabilities, and focus on strengthening their strategy to create value from their operation',

  'components of value':'In order to build and strengthen this foundation, they need to maintain 3 components of value: cost, quality/quality tools, and timeliness. Without those 3 components, the value creation for the business will continue to erode and as a result the business will face such a challenging time to survive in the market.',

  'value creation resources':'Organizations have multiple resources that work together to help create value. Collectively, they create value by helping to increase productivity. For example, putting the right equipment in place or offering professional development will help productivity. Their value is not directly related to labour but they help enhance the productivity of labour and to reduce waste. All of these value creation resources are enhancers to help improve the components of value.'
}

 
/* ex.: <span class="glossary">Camemberg</span> 
*/
$(".glossary").each(function(){
  content = $(this).html();
  content_lowercase = content.toLowerCase()
  //console.log(content_lowercase)
  definition = '<em>'+content_lowercase+'</em>: ' + glossary[content_lowercase];

  $(this).replaceWith('<span class="d-inline-block keyword-tooltip" tabindex="0" data-toggle="tooltip" data-placement="top" data-html="true" title="'+definition+'" data-original-title="text">'+content+'</span>')
})

$(".glossary-block").each(function(){
  content = $(this).html() 
  extraClass = $(this).attr('attr-addClass')
  word = $(this).attr('attr-word');
  console.log(word)
  word_lowercase = word.toLowerCase()
  //console.log(content_lowercase)//[1]
  definition = glossary[word_lowercase];

  tooltip_template = "<div class=\'tooltip tooltip-glossary \' role=\'tooltip\'><div class=\'arrow\'></div><div id=\'testing\' class=\'tooltip-inner tooltip-inner-glossary bg-brand-secondary-1-base\' ></div></div>"
 
  $(this).replaceWith('<div class="d-inline-block keyword-tooltip glossary-generated-block '+extraClass+'" tabindex="0" data-toggle="tooltip" data-animation="true" data-placement="top" data-html="true" title="'+definition+'" data-original-title="text" data-template="'+tooltip_template+'"> '+content+'</div>')
})


/* Glossaire "page" <div class=".glossary-page">
*/
$(".glossary-page").each(function(){
  
  // 1. Sort glossary{} by key name
  const ordered_glossary = Object.keys(glossary).sort().reduce(
    (obj, key) => { 
      obj[key] = glossary[key]; 
      return obj;
    }, 
    {}
  );

  // 2. Generate glossary table
  // 3. Loop through all key => value
  // 4. target specific anchors (id=letter) in table with key/value content
  
  // Generate Glossary table container  

  // ADD TABLE HEADERS
  // .....
 
  $(this).append('<div class="table-responsive table-glossary mb-medium"><table class="table mem"><tbody></tbody></table></div>');

  // Append <tr><th><td> rows id'ed by letters in alphabetical order (id=anchor)
  for (i = 10; i < 36; i++) {

    $(this).find('tbody').append('<tr><th id="'+i.toString(36)+'" rowspan="1">'+i.toString(36)+'</th><td headers="'+i.toString(36)+'"><ul></ul></td></tr>')

  }

  // Append term=>definition to correct id(id==anchor==1st letter)
  for (var key in ordered_glossary) {
    console.log(key + ":" + ordered_glossary[key]);

    curID = key.charAt(0).toString();
    console.log(curID)

    $("[headers='"+curID+"'] > ul").append('<li class="row"><div class="col-3">'+key+'</div><div class="col-5"> '+ordered_glossary[key]+'</div></li>')

  }

})



/*
ACTIVITIES
*/
$('.hiddenFeedback').hide();



/*
CARD COLLAPSIBLE MANU */
$(".show-card-collapsible-bottom").click(function(){
  $(this).closest(".card-collapsible").find(".card-collapsible-bottom").toggle();
})

/* OpenTab JQ version */
$(function(){
  $(".tablinks").click(function(){
      $(this).closest(".button-ctn").closest(".tab").find(".tablinks").removeClass("active");
      $(this).addClass("active");

      $(this).closest(".button-ctn").closest(".tab").closest(".tabs-ctn").find(".tabcontent").removeClass("visible");
      $("#"+$(this).attr("data-target")).addClass("visible");
  })
})



/* SVG Interactions */ 
  $(function () {

      $(".svg-control-box").hide();
      $(".svg-control-box[data-name='group1']").show();

      function resetSVGCells() {

          $("*[class*='-line']").addClass('hidden')
          $('*[class*="-container"]').removeClass('badge-background-active').addClass('badge-background-inactive')
          $('*[class*="-text"]').removeClass('white').addClass('blue')

          $(".svg-control-box").hide();
      }

      function highLightCell(cellId) {
          $('.' + cellId + '-line').removeClass('hidden')
          console.log('#' + cellId + '-container')
          $('.' + cellId + '-container').removeClass('badge-background-inactive').addClass('badge-background-active')
          $('.' + cellId + '-text').removeClass('blue').addClass('white')

          $(".svg-control-box[data-name='"+cellId+"']").show();
      }

      $(".trigger").click(function () {

          resetSVGCells();
          group = $(this).attr("data-name");
          //console.log(group);
          highLightCell(group);

          $(this).closest(".svg-control-box").hide();
          $(".svg-control-box[data-name='"+group+"']").show();

      })
  });



$(function () {

  // SVG-2.5 begins

  $(".svg-control-box-badge").hide();
  $(".svg-control-box-badge[data-name='group1-badge']").show();

  function resetSVGCells_badgeb() {

    $("*[class*='-badge-background']").addClass('hiddenb')
    $('*[class*="-badge-container"]').removeClass('badge-activeb').addClass('badge-inactiveb')
    $('*[class*="-badge-text"]').removeClass('whiteb').addClass('blueb')

    $(".svg-control-box-badge").hide();
  }

  function highLightCell_badgeb(groupname) {
    $('.' + groupname + '-background').removeClass('hiddenb')
    console.log(groupname + '-container')
    $('.' + groupname + '-container').removeClass('badge-inactiveb').addClass('badge-activeb')
    $('.' + groupname + '-text').removeClass('blueb').addClass('whiteb')

    $(".svg-control-box-badge[data-name='"+groupname+"']").show();
  }

  $(".trigger-badge").click(function () {

    resetSVGCells_badgeb();
    group = $(this).attr("data-name");
    console.log("data-name = "+group);
    highLightCell_badgeb(group);

  })
});
// /end SVG-2.5

/* SVG-3 Interactions */ 
$(function () {

  $(".svg-control-box").hide();
  $(".svg-control-box[data-name='integration']").show();

  function resetSVGCells() {

    $('*[class*="-text-svg3"]').removeClass('blue').addClass('darkgray')
    $('*[class*="-badge-svg3"]').removeClass('blue').addClass('lightgray')

    // $(".svg-control-box").hide();
  }

  function highLightCell(cellId) {

    $('.' + cellId + '-text-svg3').removeClass('darkgray').addClass('blue')
    $('.' + cellId + '-badge-svg3').removeClass('lightgray').addClass('blue')

    $(".svg-control-box[data-name='"+cellId+"']").show();
  }

  $(".trigger").click(function () {

    group = $(this).attr("data-name");
    resetSVGCells();

    highLightCell(group);

    $(this).closest(".svg-control-box").hide();
    $(".svg-control-box[data-name='"+group+"']").show();

  })
}); // /end SVG-3


/* SVG-4 Interactions */ 
$(function () {

  $(".svg-control-box-svg4").hide();
  $(".svg-control-box-svg4[data-name='group1']").show();

  function resetSVGCells() {

    $('*[class*="-text-svg4"]').removeClass('blue').addClass('white')
    $('*[class*="-outline-svg4"]').removeClass('burgundy').addClass('white')
    $('*[class*="-background-svg4"]').removeClass('white').addClass('blue drop-shadow')

    // $(".svg-control-box").hide();
  }

  function highLightCell(cellId) {

    $('.' + cellId + '-text-svg4').removeClass('white').addClass('blue')
    $('.' + cellId + '-outline-svg4').removeClass('white').addClass('burgundy')
    $('.' + cellId + '-background-svg4').removeClass('blue drop-shadow').addClass('white')

    $(".svg-control-box-svg4[data-name='"+cellId+"']").show();
  }

  $(".trigger-svg4").click(function () {

    group = $(this).attr("data-name");
    resetSVGCells();

    highLightCell(group);

    $(".svg-control-box-svg4").hide();
    $(".svg-control-box-svg4[data-name='"+group+"']").show();

  })
}); // /end SVG-4



/* SVG-5 Interactions */ 
$(function () {

  $(".svg-control-box-svg5").hide();
  $(".svg-control-box-svg5[data-name='group1']").show();

  function resetSVGCells() {

    $('*[class*="-arrow-svg5"]').removeClass('active').addClass('inactive')
    $('*[class*="-text-svg5"]').removeClass('active')


    // $(".svg-control-box").hide();
  }

  function highLightCell(cellId) {

    $('.' + cellId + '-arrow-svg5').removeClass('inactive').addClass('active')
    $('.' + cellId + '-text-svg5').addClass('active')

    $(".svg-control-box-svg5[data-name='"+cellId+"']").show();
  }

  $(".trigger-svg5").click(function () {

    group = $(this).attr("data-name");
    resetSVGCells();

    highLightCell(group);

    $(".svg-control-box-svg5").hide();
    $(".svg-control-box-svg5[data-name='"+group+"']").show();

  })
}); // /end SVG-5

/*

$(function(){

  $('form.activity-select select').on('change', function() {
    selectedValue = this.value;
    selectedElParent = $(this).find(':selected').attr('data-answer')
    if(selectedElParent == "correct"){
      $(this).parent().removeClass('wrong-answer').addClass('correct-answer')
    }
    else{ $(this).parent().removeClass('correct-answer').addClass('wrong-answer') }
  });



  $('.select-inRandomOrder').each(function(){
    var $select = $(this);
    var $optArr = $select.children('option');
    // sort array of list items in current select randomly
    $optArr.sort(function(a,b){
      // Get a random number between 0 and 10
      var temp = parseInt( Math.random()*10 );
      // Get 1 or 0, whether temp is odd or even
      var isOddOrEven = temp%2;
      // Get +1 or -1, whether temp greater or smaller than 5
      var isPosOrNeg = temp>5 ? 1 : -1;
      // Return -1, 0, or +1
      return( isOddOrEven*isPosOrNeg );
    })
    // append list items to select
    .appendTo($select);            
  });
}) */





