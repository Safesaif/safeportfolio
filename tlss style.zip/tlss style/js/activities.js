$(function(){

  // //////////////////////
  //
  // CHECKBOX WITH FEEDBACK
  //
  //
  $(".onclick-enableElem").change(function(){

      btnSubmit_ToEnable = $(this).attr("data-enable");
      $("#"+btnSubmit_ToEnable).removeClass("disabled");
  
   });
  
  
   $(".multiple-choice-checkbox-submit").click(
      function(){
         formId = $(this).attr("data-formId");
       
         console.log(formId);
  
         $("form#"+formId+" :input").each(function(){
            if( $(this).hasClass("correct-answer"))
            {
               /*
               html = $(this).closest(".input-group").html();
               console.log(html);
  
               $(this).closest(".input-group").html('<div class="input-group-prepend"><i class="fa fa-check-circle" aria-hidden="true" style="display: inline; padding-right:20px; margin-right:20px"></i></div>'+html);*/
  
               $(this).parent().append('&nbsp;<i class="fa fa-check-circle" aria-hidden="true" style="display: inline;"></i>');
               
            }
            else
            { $(this).parent().append('&nbsp;<i class="fa fa-times-circle" aria-hidden="true" style="display: inline;"></i>'); }
       
         });
  
      });

  ////////////
  //
  // DROPDOWN 
  //
  //
  $('form.activity-select select').on('change', function() {
    selectedValue = this.value;
    selectedElParent = $(this).find(':selected').attr('data-answer')
    if(selectedElParent == "correct"){
      $(this).parent().removeClass('select-wrong-answer').addClass('select-correct-answer')
    }
    else{ $(this).parent().removeClass('select-correct-answer').addClass('select-wrong-answer') }
  });



  $('.select-inRandomOrder').each(function(){
    var $select = $(this);
    var $optArr = $select.children('option');
    // sort array of list items in current select randomly
    $optArr.sort(function(a,b){
      // Get a random number between 0 and 10
      var temp = parseInt( Math.random()*10 );
      // Get 1 or 0, whether temp is odd or even
      var isOddOrEven = temp%2;
      // Get +1 or -1, whether temp greater or smaller than 5
      var isPosOrNeg = temp>5 ? 1 : -1;
      // Return -1, 0, or +1
      return( isOddOrEven*isPosOrNeg );
    })
    // append list items to select
    .appendTo($select);            
  });


  // ////////////////////////
  //
  // FEEDBACK ANSWER (KARINE)
  //
  //
  $('.feedback-btn').on('click', function() {
    $(this).next('.feedback-div').show();
    if (!$(this).hasClass('disabled')) {
      $(this).addClass('disabled')
    }
    $(this).next('.feedback-div').show();
  
    // if ($(this).attr('id') === 'multiChoice-btn-1') {
    // 	validateMultipleChoice('multiChoice1', 'Predictive');
    // }
  })
  
  

});


// ////////////////////////
//
// FEEDBACK ANSWER (KARINE)
//
//
function enableFeedbackbutton(target) {
if ($(target).hasClass('radio-form')) {
  $(target).next('.feedback-btn').removeClass('disabled')
} else {
  var charLength = target.value.length;
  if (charLength > 1) {
    $(target).next('.feedback-btn').removeClass('disabled')
  }
}
}

function validateMultipleChoice(formId, proof) {
let listInputs = $('#' + formId).find('ul').children('li');

listInputs.each(function() {
  let listInputValue = $(this).find('input').val();
  if (listInputValue === proof) {
    $(this).addClass('correct');
    $(this).prepend('<i class="fa fa-check-circle" aria-hidden="true" style="display: inline;"></i>')
  } else {
    $(this).addClass('incorrect');
    $(this).prepend('<i class="fa fa-times-circle" aria-hidden="true" style="display: inline;"></i>')
  }
});

$(this).addClass('disabled')
}